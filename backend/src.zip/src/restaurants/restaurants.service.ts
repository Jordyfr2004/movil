import {ConflictException,ForbiddenException,Injectable,NotFoundException,} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Restaurant } from './entities/restaurant.entity';
import { CreateRestaurantDto } from './dto/create-restaurant.dto';
import { UpdateRestaurantDto } from './dto/update-restaurant.dto';
import { User, UserRole } from '../users/entities/user.entity';
import { UpdateRestaurantStatusDto } from './dto/update-restaurant-status.dto';



@Injectable()
export class RestaurantsService {
  constructor(
    @InjectRepository(Restaurant)
    private readonly restaurantRepo: Repository<Restaurant>,

    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
  ) {}

  async create(createRestaurantDto: CreateRestaurantDto,) {
    let { name, is_active } = createRestaurantDto;

    name = name.trim();

    const existingRestaurant =
      await this.restaurantRepo.findOne({
        where: { name },
      });

    if (existingRestaurant) {
      throw new ConflictException(
        'El restaurante ya existe',
      );
    }

    const restaurant = this.restaurantRepo.create({
      name,
      is_active: is_active ?? true,
    });

    const savedRestaurant =
      await this.restaurantRepo.save(restaurant);

    return {
      message: 'Restaurante creado correctamente',
      data: savedRestaurant,
    };
  }

  async findAll() {
    return await this.restaurantRepo.find({
      where: { is_active: true},
    });
  }

  async findOnePublic(id: string) {
    const restaurant = await this.restaurantRepo.findOne({
      where: {
        id,
        is_active: true,
      },
    });

    if (!restaurant) {
      throw new NotFoundException(
        'Restaurante no encontrado o inactivo',
      );
    }

    return restaurant;
  }

  async findAllForAdmin() {
    return this.restaurantRepo.find({
      order: {
        created_at: 'DESC',
      },
    });
  }

  async findOne(id: string) {
    const restaurant = await this.restaurantRepo.findOne({
      where: { id },
    });

    if (!restaurant) {
      throw new NotFoundException('Restaurante no encontrado');
    }

    return restaurant;
  }

  async update(id: string,updateRestaurantDto: UpdateRestaurantDto,user_id: string,) {
    const user = await this.userRepo.findOne({
      where: { id: user_id },
    });

    if (!user) {
      throw new ForbiddenException(
        'No tienes permisos para esta acción',
      );
    }

    if (
      user.role !== UserRole.MANAGER &&
      user.role !== UserRole.SUPER_ADMIN
    ) {
      throw new ForbiddenException(
        'No tienes permisos para esta acción',
      );
    }

    if (
      user.role === UserRole.MANAGER &&
      user.restaurant_id !== id
    ) {
      throw new ForbiddenException(
        'Solo puedes editar el restaurante que tienes asignado',
      );
    }

    const restaurant = await this.findOne(id);

    if (updateRestaurantDto.name !== undefined) {
      const name = updateRestaurantDto.name.trim();

      const existingRestaurant =
        await this.restaurantRepo.findOne({
          where: { name },
        });

      if (
        existingRestaurant &&
        existingRestaurant.id !== id
      ) {
        throw new ConflictException(
          'El restaurante ya existe',
        );
      }

      restaurant.name = name;
    }

    const savedRestaurant =
      await this.restaurantRepo.save(restaurant);

    return {
      message: 'Restaurante actualizado correctamente',
      data: savedRestaurant,
    };
  }

  async updateStatus(id: string,updateRestaurantStatusDto: UpdateRestaurantStatusDto,) {
    const restaurant = await this.findOne(id);

    restaurant.is_active =
      updateRestaurantStatusDto.is_active;

    const savedRestaurant =
      await this.restaurantRepo.save(restaurant);

    return {
      message: savedRestaurant.is_active
        ? 'Restaurante activado correctamente'
        : 'Restaurante desactivado correctamente',
      data: savedRestaurant,
    };
  }

  async remove(id: string) {
    const restaurant = await this.findOne(id);

    await this.restaurantRepo.remove(restaurant);

    return {
      message: 'Restaurante eliminado correctamente',
    };
  }
}
